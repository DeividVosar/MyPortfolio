import "./TimelineItem.css";

/**
 * TimelineItem
 * - Single row in the education / experience timeline.
 * - The connecting line is drawn for every item except the last — parent
 *   passes `isLast` based on its array index.
 */

function TimelineItem({ date, place, role, description, isLast }) {
  return (
    <div className={`timeline-item ${isLast ? "is-last" : ""}`}>
      <div className="timeline-marker">
        <div className="timeline-dot" />
        {!isLast && <div className="timeline-line" />}
      </div>

      <div className="timeline-body">
        <p className="timeline-date">{date}</p>
        <p className="timeline-place">{place}</p>
        <p className="timeline-role">{role}</p>
        {description && <p className="timeline-description">{description}</p>}
      </div>
    </div>
  );
}

export default TimelineItem;
