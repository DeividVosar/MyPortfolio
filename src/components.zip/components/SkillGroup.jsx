import "./SkillGroup.css";

/**
 * SkillGroup
 * - A titled block of content. Used for each skill category, languages,
 *   certifications, etc. Children are whatever goes under the title.
 */

function SkillGroup({ title, children }) {
  return (
    <div className="skill-group">
      <p className="skill-group-title">{title}</p>
      {children}
    </div>
  );
}

export default SkillGroup;
