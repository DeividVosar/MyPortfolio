import { IconLink } from "./Icons";
import "./ProjectCard.css";

/**
 * ProjectCard
 * - One entry in the Projects list. Hover lift is pure CSS now.
 * - Each link is its own component (ProjectLink) so we're not calling
 *   useState inside a .map() callback like the old version did.
 * - `status` accepts "live" or "soon" — anything else is treated as "soon".
 */

function ProjectLink({ label, href }) {
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" className="project-link">
      <IconLink /> {label}
    </a>
  );
}

function StatusBadge({ status }) {
  const isLive = status === "live";
  return (
    <span className={`status-pill ${isLive ? "is-live" : "is-soon"}`}>
      {isLive ? "live" : "coming soon"}
    </span>
  );
}

function ProjectCard({ title, subtitle, status, tags, description, links }) {
  return (
    <div className="project-card">
      <div className="project-card-head">
        <div>
          <h3 className="project-title">{title}</h3>
          {subtitle && <p className="project-subtitle">{subtitle}</p>}
        </div>
        {status && <StatusBadge status={status} />}
      </div>

      <p className="project-description">{description}</p>

      <div className="project-tags">
        {tags.map((t, i) => (
          <span key={i} className="project-tag">{t}</span>
        ))}
      </div>

      {links && links.length > 0 && (
        <div className="project-links">
          {links.map((link, i) => (
            <ProjectLink key={i} {...link} />
          ))}
        </div>
      )}
    </div>
  );
}

export default ProjectCard;
