import { Icon } from "./Icons";
import { navItems } from "../data/nav";
import "./NavRail.css";

/**
 * NavRail
 * - Right-side vertical nav.
 * - Tooltip is a styled span inside each button; CSS shows it on :hover.
 *   No `title` attribute so the native browser tooltip doesn't conflict.
 */

function NavButton({ item, isActive, onClick }) {
  return (
    <button
      type="button"
      onClick={() => onClick(item.id)}
      className={`nav-btn ${isActive ? "is-active" : ""}`}
      aria-label={item.label}
    >
      <Icon name={item.icon} size={18} />
      <span className="nav-tooltip">{item.label}</span>
    </button>
  );
}

function NavRail({ active, onNavigate }) {
  return (
    <nav className="nav-rail">
      {navItems.map((item) => (
        <NavButton
          key={item.id}
          item={item}
          isActive={active === item.id}
          onClick={onNavigate}
        />
      ))}
    </nav>
  );
}

export default NavRail;
