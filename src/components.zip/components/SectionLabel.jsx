import "./SectionLabel.css";

/**
 * SectionLabel
 * - Small red label + divider line at the top of each section.
 * - Used by About, Resume, Skills, Projects.
 */

function SectionLabel({ text }) {
  return (
    <div className="section-label">
      <span className="section-label-text">{text}</span>
      <div className="section-label-line" />
    </div>
  );
}

export default SectionLabel;
