import "./Tag.css";

/**
 * Tag / Tags
 * - Small pill-style labels. `accent` gives the red-tinted style used for
 *   the Programming group.
 * - Hover effect is pure CSS now — no useState needed per tag.
 */

function Tag({ label, accent }) {
  return (
    <span className={`tag ${accent ? "is-accent" : ""}`}>{label}</span>
  );
}

function Tags({ items, accent }) {
  return (
    <div className="tag-row">
      {items.map((t, i) => (
        <Tag key={i} label={t} accent={accent} />
      ))}
    </div>
  );
}

export { Tag };
export default Tags;
